package com.acko.assignment.ackoassignment;

import org.junit.Test;

import com.acko.assignment.ackoassignment.comparator.Comparator;



/**
 * Unit test for simple App.
 */
public class ComparatorTest

{
	Comparator comparator = new Comparator();

	@Test
	public void testComparator()
	{
		String fileName1 = "UrlFile1.txt";
		String fileName2 = "UrlFile2.txt";
		comparator.compareApiResponse(fileName1, fileName2);
	}
}
