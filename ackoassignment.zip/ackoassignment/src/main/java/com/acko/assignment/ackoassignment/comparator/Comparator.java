package com.acko.assignment.ackoassignment.comparator;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;

public class Comparator
{
	public boolean compareApiResponse(String fileName1, String fileName2)
	{
		boolean isSimmilar = false;
		List<String> urlList1 = null;
		List<String> urlList2 = null;
		try
		{
			urlList1 = getListFromFile(fileName1);
			urlList2 = getListFromFile(fileName2);
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}

		// considering size of both list may not be same

		int maxSize = urlList1.size() > urlList2.size() ? urlList1.size() : urlList2.size();

		for (int i = 0; i < maxSize; i++)
		{
			if (urlList1.size() > i && urlList2.size() > i)
			{
				try
				{
					isSimmilar = compareResponse(urlList1.get(i).trim(), urlList2.get(i).trim());
				}
				catch (ClientProtocolException cpe)
				{
					cpe.printStackTrace();
				}
				catch (IOException ioe)
				{
					ioe.printStackTrace();
				}
				catch (Exception e)

				{
					e.printStackTrace();
				}
				if (isSimmilar)
				{
					System.out.println(urlList1.get(i) + " is siommilar to " + urlList2.get(i));
				}
				else
				{
					System.out.println(urlList1.get(i) + " is not siommilar to " + urlList2.get(i));
				}
			}
			else
			{
				System.out.println("Size of both the string is not same so can not be compared for remaining item.");
			}
		}
		return isSimmilar;

	}

	public List<String> getListFromFile(String fileName) throws IOException
	{
		List<String> fileNameList = new LinkedList<String>();

		File file = new File(fileName);

		BufferedReader br = new BufferedReader(new FileReader(file));

		String st;

		while ((st = br.readLine()) != null)
			fileNameList.add(st);

		return fileNameList;
	}

	public boolean compareResponse(String url1, String url2) throws ClientProtocolException, IOException
	{
		boolean isSimmilar = false;
		HttpClient client = new DefaultHttpClient();
		HttpGet httpget = new HttpGet(url1);

		ResponseHandler<String> responseHandler = new BasicResponseHandler();

		String response1 = client.execute(httpget, responseHandler);

		httpget = new HttpGet(url2);

		String response2 = client.execute(httpget, responseHandler);

		if (response1.equalsIgnoreCase(response2))
		{
			isSimmilar = true;
		}
		else
		{
			isSimmilar = false;
		}
		return isSimmilar;
	}
}
